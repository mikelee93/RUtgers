# Assignment 3 - Photos

Me:  Ryan Coslove  
Partner: Jason Dao

Grade: 221/225 (98.22%)

Grading Rubric is provided
