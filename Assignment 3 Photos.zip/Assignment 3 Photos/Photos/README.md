## Photos Project for CS213 Assignment 3

Group Number: 38  
Ryan Coslove (rmc326), section 3  
Jason Dao (jnd88), section 1