SongLib.java

package application;

import java.io.IOException;

import javafx.application.Application;

import javafx.fxml.FXMLLoader;

import javafx.scene.Scene;

import javafx.scene.layout.BorderPane;

import javafx.stage.Stage;

public class SongLib extends Application

{

private Stage primaryStage;

private BorderPane mainLayout;

@Override

public void start(Stage primaryStage) throws Exception

{

// TODO Auto-generated method stub

this.primaryStage = primaryStage;

this.primaryStage.setTitle("Songs Application");

showDatabaseView();

}

private void showDatabaseView() throws IOException

{

FXMLLoader loader = new FXMLLoader();

loader.setLocation(getClass().getResource("SongsDataBaseDesign.fxml"));

mainLayout = loader.load();

Scene scene = new Scene(mainLayout);

primaryStage.setScene(scene);

primaryStage.show();

}

public static void main(String args[])

{

launch(args);

}

}

Song.java

package application;

public class Song

{

private String name;

private String artist;

private String album;

private String year;

public Song()

{

name = "";artist="";

album = "";

year = "1990";

}

public Song(String name, String artist, String album, String year)

{

setName(name);

setArtist(artist);

setAlbum(album);

setYear(year);

}

public String getName()

{

return name;

}

public void setName(String name)

{

this.name = name;

}

public String getArtist()

{

return artist;

}

public void setArtist(String artist)

{

this.artist = artist;

}

public String getAlbum()

{

return album;

}

public void setAlbum(String album)

{

this.album = album;

}

public String getYear()

{

return year;

}

public void setYear(String year)

{

this.year = year;

}

public String toString()

{

String result = String.format("%15s \t %15s \t %30s \t %10s",name, artist, album, year);

return result;

}

}

SongsController.java

package application;

import java.net.URL;

import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.collections.FXCollections;

import javafx.collections.ObservableList;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;

import javafx.fxml.Initializable;

import javafx.scene.control.Button;

import javafx.scene.control.ListView;

import javafx.scene.control.TableColumn;

import javafx.scene.control.TableRow;

import javafx.scene.control.TableView;

import javafx.scene.control.TextField;

import javafx.scene.control.cell.PropertyValueFactory;

import javafx.scene.input.MouseEvent;

public class SongsController implements Initializable

{

@FXML

private SongLib main;

@FXML

private TextField textsongName;

@FXML

private TextField textsongArtist;

@FXML

private TextField textsongAlbum;

@FXML

private TextField textsongYear;

@FXML

private ListView<Song> listViewSongs;

@FXML

private Button btnAddSong,btnEditSong, btnDeleteSong;

public ObservableList<Song> songsList = FXCollections.observableArrayList();

@FXML

public void addEditDeletSong(ActionEvent e)

{

if (e.getSource() == btnAddSong)

{

String name = textsongName.getText();

String artist = textsongArtist.getText();

String album = textsongAlbum.getText();

String year = textsongYear.getText();

int value = JOptionPane.showConfirmDialog(null, "Would you like to add the data? ");

if (value == 0)

{

Song song = new Song(name, artist, album, year);

listViewSongs.getItems().add(song);

clearText();

}

else

{

clearText();

JOptionPane.showConfirmDialog(null, "Okay, did not add the song");

}

}

if(e.getSource() == btnEditSong)

{

/*Song song = (Song) listViewSongs.getSelectionModel().getSelectedItem();

textsongName.setText(song.getName());

textsongArtist.setText(song.getArtist());

textsongAlbum.setText(song.getAlbum());

textsongYear.setText(song.getYear());*/

}

}

@FXML

public void getSelectedItem(MouseEvent mouse) throws Exception

{

if(listViewSongs.getSelectionModel().getSelectedIndex()>=0)

{

Song song = (Song) listViewSongs.getSelectionModel().getSelectedItem();

textsongName.setText(song.getName());

textsongArtist.setText(song.getArtist());

textsongAlbum.setText(song.getAlbum());

textsongYear.setText(song.getYear());

}

}

@Override

public void initialize(URL location, ResourceBundle resources)

{

listViewSongs.setItems(songsList);

}

private void clearText()

{

textsongName.setText("");

textsongArtist.setText("");

textsongAlbum.setText("");

textsongYear.setText("");

}

}

SongsDataBaseDesign.fxml

<?xml version="1.0" encoding="UTF-8"?>

<?import javafx.geometry.Insets?>

<?import javafx.scene.control.Button?>

<?import javafx.scene.control.Label?>

<?import javafx.scene.control.ListView?>

<?import javafx.scene.control.SplitPane?>

<?import javafx.scene.control.TextField?>

<?import javafx.scene.layout.AnchorPane?>

<?import javafx.scene.layout.BorderPane?>

<?import javafx.scene.layout.ColumnConstraints?>

<?import javafx.scene.layout.GridPane?>

<?import javafx.scene.layout.RowConstraints?>

<?import javafx.scene.text.Font?>

<BorderPane prefHeight="700.0" prefWidth="800.0" xmlns="http://javafx.com/javafx/11.0.1" xmlns:fx="http://javafx.com/fxml/1" fx:controller="application.SongsController">

<center>

<SplitPane dividerPositions="0.41846819024088944" orientation="VERTICAL" prefHeight="200.0" prefWidth="160.0" BorderPane.alignment="CENTER">

<items>

<AnchorPane minHeight="0.0" minWidth="0.0" prefHeight="100.0" prefWidth="160.0">

<children>

<GridPane prefHeight="251.0" prefWidth="764.0" AnchorPane.bottomAnchor="69.0" AnchorPane.leftAnchor="0.0" AnchorPane.rightAnchor="34.0" AnchorPane.topAnchor="0.0">

<columnConstraints>

<ColumnConstraints hgrow="SOMETIMES" maxWidth="326.4000244140625" minWidth="10.0" prefWidth="166.00001220703126" />

<ColumnConstraints hgrow="SOMETIMES" maxWidth="527.2000274658203" minWidth="10.0" prefWidth="438.7999877929687" />

</columnConstraints>

<rowConstraints>

<RowConstraints minHeight="10.0" prefHeight="30.0" vgrow="SOMETIMES" />

<RowConstraints minHeight="10.0" prefHeight="30.0" vgrow="SOMETIMES" />

<RowConstraints minHeight="10.0" prefHeight="30.0" vgrow="SOMETIMES" />

<RowConstraints minHeight="10.0" prefHeight="30.0" vgrow="SOMETIMES" />

</rowConstraints>

<children>

<Label text="Name of the Song: " />

<Label text="Artist:" GridPane.rowIndex="1" />

<Label text="Album:" GridPane.rowIndex="2" />

<Label text="Year" GridPane.rowIndex="3" />

<TextField fx:id="textsongName" GridPane.columnIndex="1">

<GridPane.margin>

<Insets right="50.0" />

</GridPane.margin></TextField>

<TextField fx:id="textsongArtist" GridPane.columnIndex="1" GridPane.rowIndex="1">

<GridPane.margin>

<Insets right="50.0" />

</GridPane.margin></TextField>

<TextField fx:id="textsongAlbum" GridPane.columnIndex="1" GridPane.rowIndex="2">

<GridPane.margin>

<Insets right="50.0" />

</GridPane.margin></TextField>

<TextField fx:id="textsongYear" GridPane.columnIndex="1" GridPane.rowIndex="3">

<GridPane.margin>

<Insets right="50.0" />

</GridPane.margin></TextField>

</children>

<padding>

<Insets bottom="20.0" left="80.0" right="80.0" top="20.0" />

</padding>

</GridPane>

<Button fx:id="btnAddSong" layoutX="120.0" layoutY="223.0" mnemonicParsing="false" onAction="#addEditDeletSong" prefHeight="32.0" prefWidth="127.0" text="Add Song" />

<Button fx:id="btnEditSong" layoutX="301.0" layoutY="222.0" mnemonicParsing="false" onAction="#addEditDeletSong" prefHeight="34.0" prefWidth="136.0" text="Edit" />

<Button fx:id="btnDeleteSong" layoutX="489.0" layoutY="223.0" mnemonicParsing="false" prefHeight="32.0" prefWidth="134.0" text="Button" />

</children>

</AnchorPane>

<AnchorPane minHeight="0.0" minWidth="0.0" prefHeight="391.0" prefWidth="775.0">

<children>

<ListView fx:id="listViewSongs" layoutX="34.0" layoutY="55.0" onMousePressed="#getSelectedItem" prefHeight="312.0" prefWidth="731.0" />

<Label layoutX="251.0" layoutY="32.0" text="Artist/s Name">

<font>

<Font size="14.0" />

</font>

</Label>

<Label layoutX="34.0" layoutY="1.0" text="Songs List: ">

<font>

<Font size="18.0" />

</font>

</Label>

<Label layoutX="70.0" layoutY="32.0" text="Name of the Song">

<font>

<Font size="14.0" />

</font>

</Label>

<Label layoutX="421.0" layoutY="32.0" text="Name of the Album">

<font>

<Font size="14.0" />

</font>

</Label>

<Label layoutX="584.0" layoutY="32.0" text="Year Released">

<font>

<Font size="14.0" />

</font>

</Label>

</children>

</AnchorPane>

</items>

</SplitPane>

</center>

<top>

<Label text="Songs Data" BorderPane.alignment="CENTER" />

</top>

</BorderPane>