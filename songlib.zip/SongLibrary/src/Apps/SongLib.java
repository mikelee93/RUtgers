package Apps;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;


public class SongLib extends Application {

	public void start(Stage primaryStage) throws Exception {
		GridPane root = makeGridPane();
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	private static GridPane makeGridPane() {
		Text ftext = new Text("")
	}

}
