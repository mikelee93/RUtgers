# songlib
A simple song library Java program with JavaFX GUI (project for CS 213)
