import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class solution {
    public static void main(String[] args){
        System.out.println("$ java uniDB");
        System.out.println("Welcome to the university databases. Queries available:");
        System.out.println("1. Search students by name.");
        System.out.println("2. Search students by year");
        System.out.println("3. Search for students with a GPA >= threshold");
        System.out.println("4. Search for students with a GPA <= threshold");
        System.out.println("5. Get department Statistics");
        System.out.println("6. Get class Statistics");
        System.out.println("7. Execute an arbitrary SQL query");
        System.out.println("8. Exit the application");
        System.out.println("Which query would you like to run (1-8)");

        Scanner sc= new Scanner(System.in);

        int choice = sc.nextInt();
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_video", "root", "night$321");
        Statement statement = connection.createStatement();
        while(choice<1 && choice>8){
                switch (choice){
                    case 1:
                        System.out.println("Please enter the name:");
                        String name = sc.nextLine();
                        name = name.toLowerCase();
                        ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE "+ name+" =Students.first_name or "+ name+" = last_name or "+name+" =Students.first_name+last_name");
                            while (resultset.next()) {
                                System.out.println(resultset.getString("*"));
                            }
                        break;
                    case 2:
                        System.out.println("Please enter the year:");
                        String year = sc.nextLine();
                        if (year=="Fr"){
                            ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.credit between 0 and 29");
                            while (resultset.next()) {
                                System.out.println(resultset.getString("*"));
                            }
                    }else if (year=="So"){
                            ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.credit between 30 and 59");
                            while (resultset.next()) {
                                System.out.println(resultset.getString("*"));
                            }
                    }else if (year=="Ju"){
                            ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.credit between 60 and 89");
                            while (resultset.next()) {
                                System.out.println(resultset.getString("*"));
                            }
                    }else if (year=="Sr"){
                      ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.credit >= 90 ");
                            while (resultset.next()) {
                                System.out.println(resultset.getString("*"));
                            }
                    }
                        break;
                    case 3:
                        System.out.println("Please enter the threshold:");
                        float threshold = sc.nextFloat();
                        System.out.println("Please enter the number of courses:");
                        int num = sc.nextInt();
                        ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.gpa/ "+num+ " >= "+threshold);
                        while (resultset.next()) {
                            System.out.println(resultset.getString("*"));
                        }
                        break;
                    case 4:
                        System.out.println("Please enter the threshold:");
                        float threshold = sc.nextFloat();
                        System.out.println("Please enter the number of courses:");
                        int num = sc.nextInt();
                        ResultSet resultset = statement.executeQuery("SELECT * FROM Students WHERE Students.gpa/ "+num+ " <= "+threshold);
                        while (resultset.next()) {
                            System.out.println(resultset.getString("*"));
                        }
                        break;
                    case 5:
                        System.out.println("Please enter the department:");
                        String dep = sc.nextLine();
                        ResultSet resultset = statement.executeQuery("SELECT num_of_students,gpa FROM Departments WHERE Departments.name = "+ dep);
                        while (resultset.next()) {
                            System.out.println(resultset.getString("*"));
                        }
                        break;
                    case 6:
                        System.out.println("Please enter the class name:");
                        String classname = sc.nextLine();
                        ResultSet resultset = statement.executeQuery("SELECT count(isTaking.id) FROM istaking WHERE class= "+classname+" =istaking.name ");
                        while (resultset.next()) {
                            System.out.println(resultset.getString("*"));
                        }
                        System.out.println("Grades of previous enrolles");
                        break;
                    case 7:
                        System.out.println("Please enter the query:");
                        String query = sc.nextLine();

                        ResultSet resultset = statement.executeQuery(query);
                        while (resultset.next()) {
                            System.out.println(resultset.getString("*"));
                        }
                        break;
                    case 8:
                        System.out.println("Goodbye");
                        break;
                }
            if (choice == 8){
                break;
            System.out.println("Which query would you like to run (1-8)");
            choice = sc.nextInt();
            }
        }


    }
}
