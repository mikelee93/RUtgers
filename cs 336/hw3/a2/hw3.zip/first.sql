-- creating database and tables

CREATE DATABASE jdbc;

CREATE TABLE Departments(
name varchar(4) PRIMARY KEY,
campus varchar(5)
);

CREATE TABLE Students(
first_name varchar(20),
last_name varchar(20),
id varchar(9) PRIMARY KEY,
credits int
);

CREATE TABLE Classes(
name varchar(20) PRIMARY KEY,
credits int
);

CREATE TABLE Majors(
sid int PRIMARY KEY,
dname varchar(20)
);

CREATE TABLE Minors(
sid int PRIMARY KEY,
dname varchar(20)
);


CREATE TABLE IsTaking(
sid int PRIMARY KEY,
dname varchar(20)
);


CREATE TABLE HasTaken(
sid int PRIMARY KEY,
dname varchar(20),
grade varchar(1)
);