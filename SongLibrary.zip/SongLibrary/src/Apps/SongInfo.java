package Apps;

public class SongInfo {
	// Declaring 4 main informations, the name of the song, artist, album, and the year
	String SongName;
	String Artist;
	String Album;
	String year;
	// Song information with only 2 mandatory inputs
	public SongInfo(String SongName, String Artist) {
		this.SongName = SongName;
		this.Artist = Artist;
		this.Album = "UNKNOWN";
		this.year = "UNKNOWN";
	}
	// Song information with additional inputs
	public SongInfo(String SongName, String Artist, String Album, String year) {
		this.SongName = SongName;
		this.Artist = Artist;
		this.Album = Album;
		this.year = year;
	}
	// Fetching informations
	public String getSongName() {
		return(this.SongName);
	}
	public String getArtist() {
		return(this.Artist);
	}
	public String getAlbum() {
		return(this.Album);
	}
	public String getYear() {
		return(this.year);
	}
	// Comparing the user input information of a song and check whether
	// It is a duplicate or not
	// if result == 1, then it means that there is a duplicate song
	public int compareSongInfo(SongInfo input) {
		int result = 0;
		if(SongName.toUpperCase().compareTo(input.SongName.toUpperCase())==0) {
			if(Artist.toUpperCase().compareTo(input.Artist.toUpperCase())==0) {
				result = 1;
			}
		}
		return result;
	}
	
}
